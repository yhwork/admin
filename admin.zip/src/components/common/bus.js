import Vue from 'vue';

// 使用 Event Bus:事件总线
const bus = new Vue();

export default bus;
