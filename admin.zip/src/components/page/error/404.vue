<template>
    <div>
        {{data}}
    </div>
</template>
<style lang="scss">
    
</style>
<script>
export default {
    name:'404',
    data(){
        return {
            data:404
        }
    }
}
</script>