import config from '../config'

var API_ROOT = config.API_ROOT   


// 动态
export default {
  login: `${API_ROOT}login`
}
