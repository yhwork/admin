const Config = {
  API_ROOT: 'http://test.font.iforbao.com/iforbao-system/'
}
   
module.exports = Config
